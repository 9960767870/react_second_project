import logo from './logo.svg';
import './App.css';
import { TextFrom } from './Components/TextFrom';
import Form from './Components/Form';

function App() {
  return (
    <>
    <div className="App">
    
     <TextFrom/> 
    {/* <Form/> */}
    </div>

    </>
  );
}

export default App;
