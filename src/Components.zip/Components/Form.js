import React from 'react'

export default function Form() {
    return (
        <>
            <h1>This is User Form</h1>
            <div className='container' style={{ height: "626px" }}>

                <form>

                    <div className="form-group" style={{ marginTop: "20px", marginBottom: "20px" }}>

                        <input type="UserName" className="form-control" id="exampleInputUserName" placeholder="UserName" required />
                    </div>

                    <div className="form-group" style={{ marginBottom: "20px" }}>

                        <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" required/>
                    </div>

                    <div className="form-group" style={{ marginBottom: "20px" }}>

                        <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required />
                        <small id="emailHelp" className="form-text text-muted" style={{ marginLeft: "-173px" }}>We'll never share your email with anyone else.</small>
                    </div>

                    <div className="form-group" style={{ marginBottom: "20px" }}>

                        <select className="form-select" aria-label="Default select example">
                            <option selected>Open this select menu</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="3">4</option>
                            <option value="3">5</option>
                        </select>
                    </div>

                    <div className="form-group" style={{ marginBottom: "20px" }}>
                        <textarea className="form-control" id="exampleFormControlTextarea1" rows="3" placeholder='textarea'></textarea>
                    </div>

                  <div style={{ marginBottom: "20px"}}>
                    <input type="date" style={{marginLeft: "-298px"}} />
                  </div>




                <div style={{ marginBottom: "20px", marginLeft: "-237px" }}>

                    <input type="radio" id="defaultRadio" name="example2" />
                    <label for="defaultRadio" style={{ marginRight: "10px" }} > Male </label>

                    <input type="radio" id="defaultRadio" name="example2" />
                    <label for="defaultRadio" style={{ marginRight: "10px" }}> Female </label>

                    <input type="radio" id="defaultRadio" name="example2" />
                    <label for="defaultRadio" style={{ marginRight: "10px" }}> Transgender </label>

                </div>
                <div className="form-group" style={{ marginLeft: "-178px", marginBottom: "20px" }}>

                    <input type="file" className="form-control-file" id="exampleFormControlFile1" />
                </div>

                <div className="form-check" style={{ marginBottom: "20px" }}>
                    <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                    <label className="form-check-label" for="exampleCheck1" style={{ marginLeft: "-341px" }}>Check me out</label>
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>

        </div >
        </>
    )
}
